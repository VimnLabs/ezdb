import { Backup } from 'src/core';

const backup = new Backup({
	backups: './backups',
	path: './',
	heartbeat: 60 * 1000
});

backup.create();
